# TH-Exto-Hypnobox
Repositório para criação da integração entre o CRM Hypnobox e a plataforma do Tracker Hub
