from functions.hypnobox.users import update

call_products = update()