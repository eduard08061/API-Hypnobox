from functions.hypnobox.products import update_products

call_products = update_products()