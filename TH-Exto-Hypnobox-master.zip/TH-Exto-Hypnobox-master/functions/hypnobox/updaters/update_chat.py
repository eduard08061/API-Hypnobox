from functions.hypnobox.chat import update

# Configurações que definem para coleta dos dados

# Data para amostragem de dados 
start_time =    "2018-03-06 00:00:00"
end_time =      "2018-03-06 00:00:00"
delta = 30

# Chama a função de atualização
update(start_time, end_time, delta)
